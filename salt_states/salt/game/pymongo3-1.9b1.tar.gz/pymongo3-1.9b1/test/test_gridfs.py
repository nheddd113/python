# -*- coding: utf-8 -*-
#
# Copyright 2009-2010 10gen, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for the gridfs package.
"""

from io import BytesIO
import datetime
import unittest
import threading
import time
import sys
sys.path[0:0] = [""]

import gridfs
from gridfs.errors import (FileExists,
                           NoFile)
from .test_connection import get_connection


class JustWrite(threading.Thread):

    def __init__(self, fs):
        threading.Thread.__init__(self)
        self.fs = fs

    def run(self):
        for _ in range(10):
            file = self.fs.new_file(filename="test")
            file.write(b"hello")
            file.close()


class JustRead(threading.Thread):

    def __init__(self, fs):
        threading.Thread.__init__(self)
        self.fs = fs

    def run(self):
        for _ in range(10):
            file = self.fs.get("test")
            assert file.read() == b"hello"


class TestGridfs(unittest.TestCase):

    def setUp(self):
        self.db = get_connection().pymongo_test
        self.db.drop_collection("fs.files")
        self.db.drop_collection("fs.chunks")
        self.db.drop_collection("alt.files")
        self.db.drop_collection("alt.chunks")
        self.fs = gridfs.GridFS(self.db)
        self.alt = gridfs.GridFS(self.db, "alt")

    def test_gridfs(self):
        self.assertRaises(TypeError, gridfs.GridFS, "foo")
        self.assertRaises(TypeError, gridfs.GridFS, self.db, 5)

    def test_basic(self):
        oid = self.fs.put(b"hello world")
        self.assertEqual(b"hello world", self.fs.get(oid).read())
        self.assertEqual(1, self.db.fs.files.count())
        self.assertEqual(1, self.db.fs.chunks.count())

        self.fs.delete(oid)
        self.assertRaises(NoFile, self.fs.get, oid)
        self.assertEqual(0, self.db.fs.files.count())
        self.assertEqual(0, self.db.fs.chunks.count())

        self.assertRaises(NoFile, self.fs.get, "foo")
        oid = self.fs.put(b"hello world", _id="foo")
        self.assertEqual("foo", oid)
        self.assertEqual(b"hello world", self.fs.get("foo").read())


    def test_list(self):
        self.assertEqual([], self.fs.list())
        self.fs.put(b"hello world")
        self.assertEqual([], self.fs.list())

        self.fs.put(b"", filename="mike")
        self.fs.put(b"foo", filename="test")
        self.fs.put(b"", filename="hello world")

        self.assertEqual(set(["mike", "test", "hello world"]),
                         set(self.fs.list()))

    def test_empty_file(self):
        oid = self.fs.put(b"")
        self.assertEqual(b"", self.fs.get(oid).read())
        self.assertEqual(1, self.db.fs.files.count())
        self.assertEqual(0, self.db.fs.chunks.count())

        raw = self.db.fs.files.find_one()
        self.assertEqual(0, raw["length"])
        self.assertEqual(oid, raw["_id"])
        self.assert_(isinstance(raw["uploadDate"], datetime.datetime))
        self.assertEqual(256*1024, raw["chunkSize"])
        self.assert_(isinstance(raw["md5"], str))

    def test_alt_collection(self):
        oid = self.alt.put(b"hello world")
        self.assertEqual(b"hello world", self.alt.get(oid).read())
        self.assertEqual(1, self.db.alt.files.count())
        self.assertEqual(1, self.db.alt.chunks.count())

        self.alt.delete(oid)
        self.assertRaises(NoFile, self.alt.get, oid)
        self.assertEqual(0, self.db.alt.files.count())
        self.assertEqual(0, self.db.alt.chunks.count())

        self.assertRaises(NoFile, self.alt.get, "foo")
        oid = self.alt.put(b"hello world", _id="foo")
        self.assertEqual("foo", oid)
        self.assertEqual(b"hello world", self.alt.get("foo").read())

        self.alt.put(b"", filename="mike")
        self.alt.put(b"foo", filename="test")
        self.alt.put(b"", filename="hello world")

        self.assertEqual(set(["mike", "test", "hello world"]),
                         set(self.alt.list()))

    def test_threaded_reads(self):
        self.fs.put(b"hello", _id="test")

        threads = []
        for i in range(10):
            threads.append(JustRead(self.fs))
            threads[i].start()

        for i in range(10):
            threads[i].join()

    def test_threaded_writes(self):
        threads = []
        for i in range(10):
            threads.append(JustWrite(self.fs))
            threads[i].start()

        for i in range(10):
            threads[i].join()

        f = self.fs.get_last_version("test")
        self.assertEqual(f.read(), b"hello")

    def test_get_last_version(self):
        a = self.fs.put(b"foo", filename="test")
        time.sleep(0.01)
        b = self.fs.new_file(filename="test")
        b.write(b"bar")
        b.close()
        time.sleep(0.01)
        b = b._id
        c = self.fs.put(b"baz", filename="test")

        self.assertEqual(b"baz", self.fs.get_last_version("test").read())
        self.fs.delete(c)
        self.assertEqual(b"bar", self.fs.get_last_version("test").read())
        self.fs.delete(b)
        self.assertEqual(b"foo", self.fs.get_last_version("test").read())
        self.fs.delete(a)
        self.assertRaises(NoFile, self.fs.get_last_version, "test")

    def test_get_version(self):
        self.fs.put(b"foo", filename="test")
        time.sleep(0.01)
        self.fs.put(b"bar", filename="test")
        time.sleep(0.01)
        self.fs.put(b"baz", filename="test")
        time.sleep(0.01)

        self.assertEqual(b"foo", self.fs.get_version("test", 0).read())
        self.assertEqual(b"bar", self.fs.get_version("test", 1).read())
        self.assertEqual(b"baz", self.fs.get_version("test", 2).read())

        self.assertEqual(b"baz", self.fs.get_version("test", -1).read())
        self.assertEqual(b"bar", self.fs.get_version("test", -2).read())
        self.assertEqual(b"foo", self.fs.get_version("test", -3).read())

        self.assertRaises(NoFile, self.fs.get_version, "test", 3)
        self.assertRaises(NoFile, self.fs.get_version, "test", -4)

    def test_put_filelike(self):
        oid = self.fs.put(BytesIO(b"hello world"), chunk_size=1)
        self.assertEqual(11, self.db.fs.chunks.count())
        self.assertEqual(b"hello world", self.fs.get(oid).read())

    def test_put_duplicate(self):
        oid = self.fs.put(b"hello")
        self.assertRaises(FileExists, self.fs.put, "world", _id=oid)

    def test_exists(self):
        oid = self.fs.put(b"hello")
        self.assert_(self.fs.exists(oid))
        self.assert_(self.fs.exists({"_id": oid}))
        self.assert_(self.fs.exists(_id=oid))

        self.assertFalse(self.fs.exists(filename="mike"))
        self.assertFalse(self.fs.exists("mike"))

        oid = self.fs.put(b"hello", filename="mike", foo=12)
        self.assert_(self.fs.exists(oid))
        self.assert_(self.fs.exists({"_id": oid}))
        self.assert_(self.fs.exists(_id=oid))
        self.assert_(self.fs.exists(filename="mike"))
        self.assert_(self.fs.exists({"filename": "mike"}))
        self.assert_(self.fs.exists(foo=12))
        self.assert_(self.fs.exists({"foo": 12}))
        self.assert_(self.fs.exists(foo={"$gt": 11}))
        self.assert_(self.fs.exists({"foo": {"$gt": 11}}))

        self.assertFalse(self.fs.exists(foo=13))
        self.assertFalse(self.fs.exists({"foo": 13}))
        self.assertFalse(self.fs.exists(foo={"$gt": 12}))
        self.assertFalse(self.fs.exists({"foo": {"$gt": 12}}))

    def test_put_unicode(self):
        self.assertRaises(TypeError, self.fs.put, "hello")

        oid = self.fs.put("hello", encoding="utf-8")
        self.assertEqual(b"hello", self.fs.get(oid).read())
        self.assertEqual("utf-8", self.fs.get(oid).encoding)

        oid = self.fs.put("aé", encoding="iso-8859-1")
        self.assertEqual("aé".encode("iso-8859-1"), self.fs.get(oid).read())
        self.assertEqual("iso-8859-1", self.fs.get(oid).encoding)


if __name__ == "__main__":
    unittest.main()
